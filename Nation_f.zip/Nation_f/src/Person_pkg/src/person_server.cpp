//工作空间 Nation_f
//功能包 Person_pkg
//服务端实现代码 person_server.cpp
//客户端实现代码 person_client.cpp
// server和client之间的服务通道为 /show_prime
// 服务数据文件 Prime.srv


/**
 * 该例程将执行/show_prime服务，服务数据类型Person_pkg::Prime
**/
 
#include <ros/ros.h>
#include "Person_pkg/Prime.h"

// service回调函数，输入参数req，输出参数res
bool personCallback(Person_pkg::Prime::Request  &req,
         			Person_pkg::Prime::Response &res)
{
    // 显示请求数据

    req.num = req.num - 48;
    ROS_INFO("the input is: %d ",req.num);

	bool in_result = true;	
	for(int i = 2; i <= req.num / 2; ++i)
	{
		if(req.num % i == 0)
		{
		in_result = false;
		break;
		}
	} https://github.com/DroidAITech/ROS-Academy-for-Beginners.git

    // 设置反馈数据
    res.result = in_result;

    return true;
}

int main(int argc, char **argv)
{
    // ROS节点初始化
    ros::init(argc, argv, "person_server");

    // 创建节点句柄
    ros::NodeHandle n;

    // 创建一个名为/show_prime的server，注册回调函数personCallback
    ros::ServiceServer person_service = n.advertiseService("/show_prime", personCallback);

    // 循环等待回调函数
    ROS_INFO("Ready to determine the request of the client.");
    ros::spin();

    return 0;
}


