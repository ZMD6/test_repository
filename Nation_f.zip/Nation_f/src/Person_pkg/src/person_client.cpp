//工作空间 Nation_f
//功能包 Person_pkg
//服务端实现代码 person_server.cpp
//客户端实现代码 person_client.cpp
// server和client之间的服务通道为 /show_prime
// 服务数据文件 Prime.srv


/**
 * 该例程将请求/show_prime服务，服务数据类型Person_pkg::Prime
 */

#include <ros/ros.h>
#include "Person_pkg/Prime.h"

int main(int argc, char** argv)
{
    // 初始化ROS节点
	ros::init(argc, argv, "person_client");

    // 创建节点句柄
	ros::NodeHandle node;

    // 发现/spawn服务后，创建一个服务客户端，连接名为/spawn的service
	ros::service::waitForService("/show_prime");
	ros::ServiceClient person_client = node.serviceClient<Person_pkg::Prime>("/show_prime");

    // 初始化Person_pkg::Prime的请求数据
	Person_pkg::Prime srv;
	std::cin >> srv.request.num;
	
	//for(srv.request.num=z)
	//{
		
	//}https://github.com/DroidAITech/ROS-Academy-for-Beginners.git

    // 请求服务调用
	ROS_INFO("Call service to determine if [num:%d] is prime", srv.request.num);

	person_client.call(srv);

    // 显示服务调用结果
	ROS_INFO("Show the result : %d (1 means the input is a prime num, and 0 means it's not)", srv.response.result);

	return 0;
};










