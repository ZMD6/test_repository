
"use strict";

let Prime = require('./Prime.js')

module.exports = {
  Prime: Prime,
};
