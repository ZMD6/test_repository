/**
 * 该例程产生tf数据，并计算、发布turtle2的速度指令
**/

#include<ros/ros.h>
#include<tf/transform_broadcaster.h>
#include<turtlesim/Pose.h>

std::string turtle_name;

void poseCallback(const turtlesim::PoseConstPtr& msg)
{
	// 1\创建tf的广播器
	static tf::TransformBroadcaster br;

	// 2\创建坐标变换值，初始化tf数据
	tf::Transform transform;   // 4X4平移矩阵
	// 设置平移矩阵参数
	transform.setOrigin( tf::Vector3(msg->x, msg->y, 0.0));    // (turtle1相对于word的平移)
	// 设置旋转，四元素
	tf::Quaternion q;    
	q.setRPY(0, 0, msg->theta);
	transform.setRotation(q);

	// transform.setRotation(tf::Quaternion.setRPY(0, 0, msg->theta));	
	
	// 发布坐标变换(到tf树)，广播world与两个海龟坐标系之间的tf数据
	br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "world", turtle_name));

	// StampedTransform (const tf::Transform &input, const ros::Time &timestamp, const std::string &frame_id, const std::string &child_frame_id)

}

int main(int argc, char** argv)
{
	ros::init(argc, argv, "my_tf_broadcaster");
	
	// 输入参数作为海龟的名字
	if(argc != 2)
	{
		ROS_ERROR("need turtle name as argument");
		return -1;
	}

	turtle_name = argv[1];

	// 订阅海龟姿态
	ros::NodeHandle node;
	ros::Subscriber sub = node.subscribe(turtle_name+"/pose", 10, &poseCallback);

	ros::spin();
	return 0;
};






