/**
 * 该例程将发布/person_info话题，自定义消息类型learning_topic::Person
 */
 
#include <ros/ros.h>     // ros/ros.h 是一个实用的头文件，它引用了ROS系统中大部分常用的头文件
#include "learning_topic/Person.h"    // 创建功能包话题消息后，编译生成的头文件

int main(int argc, char **argv)
{
    // ROS节点初始化。。允许ROS通过命令进行名称重映射。。
    // 指定节点的名称。【注意】运行过程中，节点的名称是唯一的
    ros::init(argc, argv, "person_publisher");

    // 创建节点句柄。【作用】第一个创建的NodeHandle会为节点进行初始化，最后一个销毁的 NodeHandle 则会释放该节点所占用的所有资源。
    ros::NodeHandle n;

    // 创建一个Publisher，发布名为/person_info的topic，消息类型为learning_topic::Person，队列长度10
    ros::Publisher person_info_pub = n.advertise<learning_topic::Person>("/person_info", 10);

    // 设置循环的频率，以 1Hz 的频率运行。即发布者发布消息的频率
    ros::Rate loop_rate(1);

    int count = 0;
    while (ros::ok())
    {
        // 初始化learning_topic::Person类型的消息
    	learning_topic::Person person_msg;
		person_msg.name = "Tom";
		person_msg.age  = 18;
		person_msg.sex  = learning_topic::Person::male;

        // 发布消息
		person_info_pub.publish(person_msg);

       	ROS_INFO("Publish Person Info: name:%s  age:%d  sex:%d", 
				  person_msg.name.c_str(), person_msg.age, person_msg.sex);

        // 按照循环频率延时，，调用 ros::Rate 对象来休眠一段时间以使得发布频率为 1Hz。
        loop_rate.sleep();
    }

    return 0;
}
